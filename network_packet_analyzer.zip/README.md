
# Network Packet Analyzer

This tool captures and analyzes network packets using Python and Scapy.

## Features

- Captures live network packets
- Extracts source and destination IPs
- Identifies protocols (TCP/UDP)
- Shows the beginning of payload data

## Requirements

Install required package:
```
pip install scapy
```

## How to Run

Use with administrator/root privileges:
```
sudo python sniffer.py
```

Ensure this tool is used **ethically** and for **educational purposes only**.
